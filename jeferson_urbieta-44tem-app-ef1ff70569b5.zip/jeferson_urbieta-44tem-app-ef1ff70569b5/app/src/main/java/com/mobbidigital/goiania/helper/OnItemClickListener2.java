package com.mobbidigital.goiania.helper;

import com.mobbidigital.goiania.modelsList.catSubCatlistModel;

public interface OnItemClickListener2 {
    void onItemClick(catSubCatlistModel item);
}
