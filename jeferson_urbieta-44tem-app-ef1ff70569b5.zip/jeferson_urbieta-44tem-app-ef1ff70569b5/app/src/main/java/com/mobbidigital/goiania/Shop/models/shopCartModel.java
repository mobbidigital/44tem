package com.mobbidigital.goiania.Shop.models;

public class shopCartModel {

    private String cartId, cartImage, cartName, cartDiscount, cartTotalPrice, cartTotalItems;

    public String getCartId() {
        return cartId;
    }

    public void setCartId(String cartId) {
        this.cartId = cartId;
    }

    public String getCartImage() {
        return cartImage;
    }

    public void setCartImage(String cartImage) {
        this.cartImage = cartImage;
    }

    public String getCartName() {
        return cartName;
    }

    public void setCartName(String cartName) {
        this.cartName = cartName;
    }

    public String getCartDiscount() {
        return cartDiscount;
    }

    public void setCartDiscount(String cartDiscount) {
        this.cartDiscount = cartDiscount;
    }

    public String getCartTotalPrice() {
        return cartTotalPrice;
    }

    public void setCartTotalPrice(String cartTotalPrice) {
        this.cartTotalPrice = cartTotalPrice;
    }

    public String getCartTotalItems() {
        return cartTotalItems;
    }

    public void setCartTotalItems(String cartTotalItems) {
        this.cartTotalItems = cartTotalItems;
    }
}
