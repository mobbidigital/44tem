package com.mobbidigital.goiania.helper;

import com.mobbidigital.goiania.modelsList.homeCatListModel;

public interface OnItemClickListener{
    void onItemClick(homeCatListModel item);
}
