package com.mobbidigital.goiania.helper;

import com.mobbidigital.goiania.modelsList.blogCommentsModel;

public interface BlogCommentOnclicklinstener {
    void onItemClick(blogCommentsModel item);
}
