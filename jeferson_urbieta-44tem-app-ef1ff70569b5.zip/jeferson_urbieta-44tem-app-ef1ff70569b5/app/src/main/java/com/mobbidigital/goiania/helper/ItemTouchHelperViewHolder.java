
package com.mobbidigital.goiania.helper;

public interface ItemTouchHelperViewHolder {

    void onItemSelected();

    void onItemClear();
}
