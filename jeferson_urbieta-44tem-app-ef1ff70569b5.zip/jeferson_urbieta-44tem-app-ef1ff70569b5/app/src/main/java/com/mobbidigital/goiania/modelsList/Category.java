package com.mobbidigital.goiania.modelsList;

public class Category {
}
