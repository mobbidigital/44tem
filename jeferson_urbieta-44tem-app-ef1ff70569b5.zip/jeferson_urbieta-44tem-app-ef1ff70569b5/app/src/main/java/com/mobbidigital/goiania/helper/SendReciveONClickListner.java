package com.mobbidigital.goiania.helper;

import com.mobbidigital.goiania.modelsList.messageSentRecivModel;

public interface SendReciveONClickListner {
    void onItemClick(messageSentRecivModel item);
}
