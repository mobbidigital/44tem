package com.mobbidigital.goiania.Shop;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.mobbidigital.goiania.R;

public class shopSearchFiltersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_search_filters);
    }
}
