package com.mobbidigital.goiania.helper;

import com.mobbidigital.goiania.modelsList.blogModel;

public interface BlogItemOnclicklinstener {
    void onItemClick(blogModel item);
}
