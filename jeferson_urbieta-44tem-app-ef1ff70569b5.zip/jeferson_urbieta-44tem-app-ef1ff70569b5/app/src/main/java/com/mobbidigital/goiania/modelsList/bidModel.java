package com.mobbidigital.goiania.modelsList;

public class bidModel {

    private String bidId;
    private String bidDate;
    private String bidPrice;
    private String bidMessage;
    private String bidImage;
    private String bidUserNmae;
    private String bidPhoneNumber;

    public String getBidId() {
        return bidId;
    }

    public void setBidId(String bidId) {
        this.bidId = bidId;
    }

    public String getBidDate() {
        return bidDate;
    }

    public void setBidDate(String bidDate) {
        this.bidDate = bidDate;
    }

    public String getBidPrice() {
        return bidPrice;
    }

    public void setBidPrice(String bidPrice) {
        this.bidPrice = bidPrice;
    }

    public String getBidMessage() {
        return bidMessage;
    }

    public void setBidMessage(String bidMessage) {
        this.bidMessage = bidMessage;
    }

    public String getBidImage() {
        return bidImage;
    }

    public void setBidImage(String bidImage) {
        this.bidImage = bidImage;
    }

    public String getBidUserNmae() {
        return bidUserNmae;
    }

    public void setBidUserNmae(String bidUserNmae) {
        this.bidUserNmae = bidUserNmae;
    }

    public String getBidPhoneNumber() {
        return bidPhoneNumber;
    }

    public void setBidPhoneNumber(String bidPhoneNumber) {
        this.bidPhoneNumber = bidPhoneNumber;
    }
}
