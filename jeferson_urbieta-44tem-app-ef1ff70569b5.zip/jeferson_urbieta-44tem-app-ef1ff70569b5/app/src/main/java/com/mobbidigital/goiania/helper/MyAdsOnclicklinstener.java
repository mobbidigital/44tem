package com.mobbidigital.goiania.helper;

import android.view.View;

import com.mobbidigital.goiania.modelsList.myAdsModel;

public interface MyAdsOnclicklinstener {

    void onItemClick(myAdsModel item);
    void delViewOnClick(View v, int position);
    void editViewOnClick(View v, int position);

}
