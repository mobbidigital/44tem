package com.mobbidigital.goiania.helper;

import com.mobbidigital.goiania.modelsList.blockUserModel;

public interface BlockUserClickListener {
    void onItemClick(blockUserModel item,int position);

}
