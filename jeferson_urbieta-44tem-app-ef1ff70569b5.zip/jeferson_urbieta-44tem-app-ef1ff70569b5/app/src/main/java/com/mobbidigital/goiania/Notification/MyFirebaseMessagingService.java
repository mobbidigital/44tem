package com.mobbidigital.goiania.Notification;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import com.mobbidigital.goiania.utills.SettingsMain;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by apple on 11/23/17.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = MyFirebaseMessagingService.class.getSimpleName();

    private NotificationUtils notificationUtils;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.e(TAG, "From: " + remoteMessage.getFrom());

        if (remoteMessage == null)
            return;

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.e(TAG, "Data Payload: " + remoteMessage.getData().toString());
            try {
                handleDataMessage(remoteMessage);
            } catch (Exception e) {
                Log.e(TAG, "Exception: " + e.getMessage());
            }
        }
    }

    private void handleDataMessage(RemoteMessage remoteMessage) {

        try {

            String title, message;

            if (remoteMessage.getData().get("topic").equals("broadcast")) {
                SettingsMain settingsMain = new SettingsMain(getApplicationContext());
                JSONObject broadcast = new JSONObject(remoteMessage.getData().get("data"));
                Log.d("info broadcat", broadcast.toString());
                title = broadcast.getString("title");
                message = broadcast.getString("message");
                String image = broadcast.getString("image");
                NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
                notificationUtils.playNotificationSound();

                Date currentTime = Calendar.getInstance().getTime();

                if (TextUtils.isEmpty(image)) {
                    settingsMain.setNotificationImage("");
                    showNotificationMessage(getApplicationContext(), title, message, currentTime, remoteMessage.getData().get("topic_id"), "", "1", "", image,
                            broadcast.getString("topic"));
                } else {
                    settingsMain.setNotificationImage(broadcast.getString("image_full"));
                    showNotificationMessageWithBigImage(getApplicationContext(), title, message, currentTime, remoteMessage.getData().get("topic_id"), "", "1", ""
                            , image, remoteMessage.getData().get("topic"));
                }
            }
            if (remoteMessage.getData().get("topic").equals("chat")) {
                title = remoteMessage.getData().get("title");
                message = remoteMessage.getData().get("message");
                String ad_id = remoteMessage.getData().get("adId");
                String recieverId = remoteMessage.getData().get("recieverId");
                String senderId = remoteMessage.getData().get("senderId");
                String type = remoteMessage.getData().get("type");


                // app is in foreground, broadcast the push message
                JSONObject json = new JSONObject(remoteMessage.getData().get("chat"));
                Intent pushNotification = new Intent(Config.PUSH_NOTIFICATION);
                pushNotification.putExtra("date", json.getString("date"));
                pushNotification.putExtra("img", json.getString("img"));
                pushNotification.putExtra("text", json.getString("text"));
                pushNotification.putExtra("type", json.getString("type"));

                pushNotification.putExtra("adIdCheck", ad_id);
                pushNotification.putExtra("recieverIdCheck", recieverId);
                pushNotification.putExtra("senderIdCheck", senderId);
                LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);

                NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
                notificationUtils.playNotificationSound();

                Date currentTime = Calendar.getInstance().getTime();
                showNotificationMessage(getApplicationContext(), title, message, currentTime, ad_id, recieverId, senderId,
                        type, "", remoteMessage.getData().get("topic"));
            }
        } catch (Exception e) {
            Log.e(TAG, "Exception:" + e.getMessage());
        }
    }

    /**
     * Showing notification with text only
     */
    private void showNotificationMessage(Context context, String title, String message, Date timeStamp, String ad_id, String recieverId, String senderId,
                                         String type, String imageURL, String topic) {
        notificationUtils = new NotificationUtils(context);
        notificationUtils.showNotificationMessage(title, message, timeStamp, ad_id, recieverId, senderId, type, imageURL, topic);
    }

    /**
     * Showing notification with text and image
     */
    private void showNotificationMessageWithBigImage(Context context, String title, String message, Date timeStamp, String ad_id, String recieverId,
                                                     String senderId, String type, String imageURL, String topic) {
        notificationUtils = new NotificationUtils(context);
        notificationUtils.showNotificationMessage(title, message, timeStamp, ad_id, recieverId, senderId, type, imageURL, topic);
    }
}