package com.mobbidigital.goiania.Shop.models;

public class shopFeatureDetailsModel {
    private String textViewKey, textViewValue;

    public String getTextViewValue() {
        return textViewValue;
    }

    public void setTextViewValue(String textViewValue) {
        this.textViewValue = textViewValue;
    }

    public String getTextViewKey() {
        return textViewKey;
    }

    public void setTextViewKey(String textViewKey) {
        this.textViewKey = textViewKey;
    }
}
